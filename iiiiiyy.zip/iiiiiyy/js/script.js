function validateForm() {
    let x=document.forms['myForm']['fname'].value
    if (x == '') {
        alert('form must be filled')
        return false
    }
}